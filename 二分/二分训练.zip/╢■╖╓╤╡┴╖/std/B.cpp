#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
const int N = 1e4 + 5;
const double eps = 1e-7;

int n, k;
double len[N];

int valid(double x)
{
	int sum = 0;
	for (int i = 0; i < n; i++)
	{
		sum += (int)(len[i] / x);
	}
	return sum >= k;
}

int main()
{
	scanf("%d%d", &n, &k);
	for (int i = 0; i < n; i++)
	{
		scanf("%lf", &len[i]);
	}
	double l = 0.0, r = 1e5 + 5;
	while (r - l > eps)
	{
		double mid = (l + r) / 2;
		if (valid(mid)) l = mid;
		else r = mid;
	}
	printf("%.2f\n", floor(r * 100) / 100); //输出需要注意一下

	return 0;
}
