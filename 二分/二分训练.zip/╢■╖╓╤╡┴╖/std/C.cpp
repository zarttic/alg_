#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
const int N = 1e5 + 10;
int a[N];
int m, n;
bool valid(int x)
{
	int sum = 1, tem = 1;
	for (int i = 2; i <= m; i++)
	{
		if (a[i] - a[tem] >= x)
		{
			sum++;
			tem = i;
		}
	}
	return sum >= n;
}
int main()
{
	scanf("%d%d", &m, &n);
	for (int i = 1; i <= m; i++)
	{
		scanf("%d", &a[i]);
	}
	sort(a + 1, a + m);
	int l = a[1], r = a[m];
	int mid = l + (r - l) / 2;
	while (r - l > 1)
	{
		mid = l + (r - l) / 2;
		if (valid(mid))
		{
			l = mid;
		}
		else
		{
			r = mid;
		}
	}
	printf("%d\n", l);
}


