#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
const int INF = 0x3f3f3f3f;
const int N = 50010;
int l, r, n, m, ans, a[N];
bool valid(int mid)
{
	int last = -INF, cnt = 0;
	for (int i = 0; i <= n + 1; i++)
	{
		if (a[i] >= last + mid)
		{
			cnt++;
			last = a[i];
		}
	}
	return cnt >= n + 2 - m;
}
int main()
{
	scanf("%d%d%d", &l, &n, &m);
	r = l;
	l = 0;
	a[0] = 0, a[n + 1] = r;
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	sort(a, a + n + 2);
	while (l <= r)
	{
		int mid = (l + r) >> 1;
		if (valid(mid))
		{
			ans = mid;
			l = mid + 1;
		}
		else
		{
			r = mid - 1;
		}
	}
	printf("%d", ans);
}

