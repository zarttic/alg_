#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
typedef long long ll;
const int N = 1e3 + 10;
const double eps = 1e-7;
int n, k;
int a[N], b[N];
double tem[N];

bool cmp(double a,double b){return a>b;}
bool valid(double x)
{
	for (int i = 1; i <= n; i++) tem[i] = a[i] - x * b[i];

//	sort(tem + 1, tem + n + 1, [](double a, double b){return a > b;}); poj不支持
	sort(tem + 1, tem + n + 1, cmp);
	double sum = 0.0;
	for (int i = 1; i <= n - k; i++) sum += tem[i];
	return sum > 0;
}

int main()
{
	while (~scanf("%d%d", &n, &k) && n + k)
	{
		for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
		for (int i = 1; i <= n; i++) scanf("%d", &b[i]);
		double l = 0.0, r = 1.1;
		while (r - l >= eps)
		{
			double mid = (l + r) / 2;
			if (valid(mid)) l = mid;
			else r = mid;
		}
		double ans = (l + r) / 2;
		printf("%.0f\n", (ans * 100));
	}
}
