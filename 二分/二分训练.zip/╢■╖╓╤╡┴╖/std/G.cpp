#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>
#define ll long long
#define eps 1e-6
#define double long double
const int N = 2e5 + 10;
int L, R, n, ar, al, a[N], q[N];
double sum[N];
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
bool valid(double m)
{
	int i, top, back, now;
	for (i = 1; i <= n; i++)
		sum[i] = sum[i - 1] + a[i] - m;
	top = 0, back = 1;
	now = 0;
	for (i = 2; i <= n; i += 2)
	{
		while (i - now >= L)
		{
			while (back <= top && sum[q[top]] >= sum[now])
				top--;
			q[++top] = now;
			now += 2;
		}
		while (back <= top && i - q[back] > R)
			back++;
		if (back <= top)
		{
			if (sum[i] - sum[q[back]] >= 0)
			{
				al = q[back], ar = i;
				return true;
			}
		}
	}
	top = 0, back = 1;
	now = 1;
	for (i = 3; i <= n; i += 2)
	{
		while (i - now >= L)
		{
			while (back <= top && sum[q[top]] >= sum[now])
				top--;
			q[++top] = now;
			now += 2;
		}
		while (back <= top && i - q[back] > R)
			back++;
		if (back <= top)
		{
			if (sum[i] - sum[q[back]] >= 0)
			{
				al = q[back], ar = i;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	int i;
	ll p, qq, t;
	double l, r, m;
	scanf("%d%d%d", &n, &L, &R);
	for (i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
		a[i + n] = a[i];
	}
	n *= 2;
	l = 0, r = 1000000000;
	while (l + eps < r)
	{
		m = (l + r) / 2;
		if (valid(m))
			l = m;
		else
			r = m;
	}
	if (l <= eps)
		valid(0);
	p = 0, qq = ar - al;
	for (i = al + 1; i <= ar; i++)
		p += a[i];
	t = gcd(p, qq);
	if (p % qq == 0)
		printf("%lld\n", p / qq);
	else
		printf("%lld/%lld\n", p / t, qq / t);
	return 0;
}
