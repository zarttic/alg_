#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>


using namespace std;

typedef long long ll;
const int N = 1e4 + 5;
typedef pair<ll, ll>P;

struct qnode
{
	int v, c;
	qnode(int _v = 0, int _c = 0): v(_v), c(_c) {}
	bool operator < (const qnode &r) const
	{
		return c > r.c;
	}
};

struct node
{
	int to, index, w;
} E[N << 1];

int head[N], cnt;
int n, m, k, dis[N];
bool vis[N];
void add(int u, int v, int w)
{
	E[++cnt].to = v;
	E[cnt].w = w;
	E[cnt].index = head[u];
	head[u] = cnt;
	E[++cnt].to = u;
	E[cnt].w = w;
	E[cnt].index = head[v];
	head[v] = cnt;
}

bool dji(int x)
{
	memset(dis, 0x3f, sizeof(dis));
	memset(vis, false, sizeof(vis));
	priority_queue<qnode>que;
	que.push(qnode(1, 0));
	dis[1] = 0;
	while (!que.empty())
	{
		qnode top = que.top();
		que.pop();
		int u = top.v;
		if (vis[u]) continue;
		vis[u] = true;
		for (int i = head[u]; i; i = E[i].index)
		{
			int v = E[i].to;
			int cost = (E[i].w >= x);
			if (!vis[v] && dis[v] > dis[u] + cost)
			{
				dis[v] = dis[u] + cost;
				que.push(qnode(v, dis[v]));
			}
		}
	}
	return dis[n] >= k + 1;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> m >> k;
	for (int i = 0; i < m; i++)
	{
		int u, v, w;
		cin >> u >> v >> w;
		add(u, v, w);
	}
	int l = 0, r = 1000002, ans = -1;
	while (l <= r)
	{
		int mid = (l + r) >> 1;
		if (dji(mid))
		{
			l = mid + 1;
			ans = mid;
		}
		else r = mid - 1;
	}
	if (l > 1000000) ans = -1;
	if (r < 0) ans = 0;
	cout << ans << endl;
	return 0;
}


