#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>

#define fi first
#define se second
using namespace std;
typedef pair< pair<int, int>, pair<int, int> > Edge;
const int maxn = 5e4, maxe = 1e5;

int n, m, K;
Edge e[maxe + 5];
int fa[maxn + 5], now, ans;

#define val(e) (e.se.fi+now*(e.se.se^1))
inline bool cmp(Edge a, Edge b)
{
	return val(a) < val(b) || val(a) == val(b) && a.se.se < b.se.se;
}
int getfa(int x)
{
	if (fa[x] == x) return x;
	return fa[x] == x ? x : fa[x] = getfa(fa[x]);
}
inline bool check(int mid)
{
	int tot = 0;
	ans = 0;
	now = mid;
	for (int i = 0; i < n; i++) fa[i] = i;
	sort(e + 1, e + 1 + m, cmp);
	for (int i = 1; i <= m; i++)
	{
		int fx = getfa(e[i].fi.fi), fy = getfa(e[i].fi.se);
		if (fx == fy) continue;
		ans += val(e[i]);
		tot += !e[i].se.se;
		fa[fx] = fy;
	}
	return tot >= K;
}
int main()
{
	scanf("%d%d%d", &n, &m, &K);
	for (int i = 1; i <= m; i++) scanf("%d%d%d%d", &e[i].fi.fi, &e[i].fi.se, &e[i].se.fi, &e[i].se.se);
	int L = -105, R = 105;
	for (int mid = L + (R - L >> 1); L <= R; mid = L + (R - L >> 1)) if (check(mid)) L = mid + 1;
		else R = mid - 1;
	return check(R), printf("%d\n", ans - R * K), 0;
}
