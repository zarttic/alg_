#pragma GCC optimize("-O2")
#define _CRT_SBCURE_NO_DEPRECATE
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <functional>

#define fi first
#define se second
#define pb push_back



typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int, int> pii;


const int N = 100000 + 7;
const double eps = 1e-8;

int n, m, cnt;

inline int dcmp(const double &x)
{
	return fabs(x) <= eps ? 0 : (x < 0 ? -1 : 1);
}
struct Point
{
	double x, y;
	inline Point(const double &x = 0, const double &y = 0) : x(x), y(y) {}
} a[N], b[N], ans[N];

inline double dist(const Point &a, const Point &b)
{
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}
inline Point get_C(const Point &p1, const Point &p2, const Point &p3)
{
	double c1 = (p1.x * p1.x + p1.y * p1.y) - (p2.x * p2.x + p2.y * p2.y), a1 = 2 * (p1.x - p2.x), b1 = 2 * (p1.y - p2.y);
	double c2 = (p2.x * p2.x + p2.y * p2.y) - (p3.x * p3.x + p3.y * p3.y), a2 = 2 * (p2.x - p3.x), b2 = 2 * (p2.y - p3.y);
	double x = (b1 * c2 - b2 * c1) / (a2 * b1 - a1 * b2), y = (a1 * c2 - a2 * c1) / (a1 * b2 - a2 * b1);
	return Point(x, y);
}

inline std::pair<Point, double> calc(int L, int R)
{
	int n = 0;
	for (int i = L; i <= R; ++i) b[++n] = a[i];
	std::random_shuffle(b + 1, b + n + 1);
	Point O = b[1];
	double r = 0;
	for (int i = 2; i <= n; ++i) if (dcmp(dist(O, b[i]) - r) > 0)
		{
			O = b[i], r = 0;
			for (int j = 1; j < i; ++j) if (dcmp(dist(O, b[j]) - r) > 0)
				{
					O = Point((b[i].x + b[j].x) / 2, (b[i].y + b[j].y) / 2), r = dist(b[i], O);
					for (int k = 1; k < j; ++k) if (dcmp(dist(O, b[k]) - r) > 0)
						{
							O = get_C(b[i], b[j], b[k]);
							r = dist(b[i], O);
						}
				}
		}
	return std::make_pair(O, r);
}

inline bool check(const double &mid)
{
	cnt = 0;
	int now = 1;
	while (now <= n)
	{
		int i = 1;
		for (; now + (1 << i) - 1 <= n; ++i)
			if (calc(now, now + (1 << i) - 1).se - mid > eps) break;
		int l = now + (1 << (i - 1)) - 1, r = std::min(now + (1 << i) - 2, n);
		while (l < r)
		{
			int mid2 = (l + r + 1) >> 1;
			if (calc(now, mid2).se - mid < eps) l = mid2;
			else r = mid2 - 1;
		}
		ans[++cnt] = calc(now, l).fi, now = l + 1;
	}
	return cnt <= m;
}

inline void slove()
{
	double l = 0, r = 2000000;
	while (r - l >= eps)
	{
		double mid = (l + r) / 2;
		if (check(mid)) r = mid;
		else l = mid;
	}
	printf("%.8lf\n", r);
	check(r);
	printf("%d\n", cnt);
	for (int i = 1; i <= cnt; ++i) printf("%.8lf %.8lf\n", ans[i].x, ans[i].y);
}

inline void init()
{
	srand(time(0) + (ull)new char);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) scanf("%lf%lf", &a[i].x, &a[i].y);
}

int main()
{
	init();
	slove();
	return 0;
}
